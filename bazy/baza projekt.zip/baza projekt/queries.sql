use ZaliczenieBD_181960

--1. kwerenda wyszukuj�ca �redni wiek Pilota i �redni� liczb� godzin sp�dzonych w powietrzu z rozr�nieniem p�ci

select P�e�, avg(Wiek) as �redniWiekPilota, avg(Ilo��GodzinLotu) as �redniaLiczbaGodzin
from Pilot
group by P�e�;

--2. Kwerenda wyszukuj�ca modele samolot�w rejsowych z maksymaln� pr�dko�ci� wi�ksz� ni� 800km/h

select Model, CzyRejsowy, MaksPr�dko��
from Samolot
where CzyRejsowy=1 and MaksPr�dko�� > 800;

--3. Kwerenda wyszukuj�ca loty do Meksyku po 25 czerwca 2020

select IdLotu, DataWylotu, CelLotu
from Lot
where CelLotu='Mexico' and DataWylotu > '2020-06-25';

--4. Kwerenda pokazuj�ca nazwiska pilot�w lataj�cych do Brazylii, Meksyku lub Maroka

select p.Nazwisko, l.CelLotu
from Lot as l inner join Pilot as p on l.IdPilota = p.IdPilota
where l.CelLotu in ('Brazil','Mexico','Morocco');

--5. Kwerenda pokazuj�ca nazwiska i id pasa�er�w wylatuj�cych w godzinach wieczornych (po 20:00)

select distinct p.Nazwisko, p.IdPasa�era
from Pasa�er as p inner join Bilet as b on p.IdPasa�era = b.IdPasa�era inner join Lot as l on b.IdLotu = l.IdLotu
where l.GodzinaWylotu > '20:00:00';

--6. Kwerenda znajduj�ca samolot o najwi�kszej pojemno�ci baku, kt�ry pilotowa�a kobieta

select max(s.Pojemno��Baku)
from Samolot as s inner join Lot as l on l.IdSamolotu = s.IdSamolotu inner join Pilot as p on p.IdPilota = l.IdPilota
where p.P�e�='K';

--7. Update: zwi�kszenie maksymalnej pr�dko�ci samolot�w o 5%, je�li maj� pojemno�� przynajmniej 20000 litr�w

update Samolot
set MaksPr�dko��=MaksPr�dko��*1.05
where Pojemno��Baku > 20000;

--8. Update: Liczba godzin w powietrzu pilot�w p�ci �e�skiej je�li lata�y na samolotach modelu Cessna zwi�kszona o 100

update P
set P.Ilo��GodzinLotu = P.Ilo��GodzinLotu + 100
from Pilot as P 
inner join Lot as L on P.IdPilota = L.IdPilota
inner join Samolot as S on L.IdSamolotu = S.IdSamolotu
where P.P�e�='K' and S.Model like 'Cessna%';

--9. Update: Zmiana celu podr�y dla lot�w pomi�dzy 07.03.2020 a 01.05.2020 na Germany, je�li lecia� samolot rejsowy.

update L
set L.CelLotu='Germany'
from Lot as L
inner join Samolot as S on L.IdSamolotu = S.IdSamolotu
where L.DataWylotu between '2020-03-07' and '2020-05-01' and S.CzyRejsowy=1;


--10. Alter table: Dodanie kolumny Email dla Pasa�era

alter table Pasa�er
add Email varchar(80);

--11. Alter table: Usuni�cie kolumny Email Pasa�era

alter table Pasa�er
drop column Email;

--12. Alter table: Zmiana maksymalnej pr�dko�ci samolotu na typ varchar(3)

alter table Samolot
alter column MaksPr�dko�� varchar(3) not null;

--13. Widok do kwerendy 3
go

create view Kwerenda3Widok as
select IdLotu, DataWylotu, CelLotu
from Lot
where CelLotu='Mexico' and DataWylotu > '2020-06-25';


--14. Widok do kwerendy 4
go

create view Kwerenda4Widok as
select p.Nazwisko, l.CelLotu
from Lot as l inner join Pilot as p on l.IdPilota = p.IdPilota
where l.CelLotu in ('Brazil','Mexico','Morocco');

--15. Widok do kwerendy 6
go

create view Kwerenda6Widok as
select max(s.Pojemno��Baku) as MaksPojemnosc
from Samolot as s inner join Lot as l on l.IdSamolotu = s.IdSamolotu inner join Pilot as p on p.IdPilota = l.IdPilota
where p.P�e�='K';

--16. Join Lewostronny 
go

select Lot.CelLotu, Samolot.MaksPr�dko��
from Lot left join Samolot on Lot.IdSamolotu = Samolot.IdSamolotu
order by Samolot.MaksPr�dko�� asc

--17. Join Prawostronny

select Bilet.IdPasa�era, Lot.DataWylotu
from Bilet right join Lot on Bilet.IdLotu = Lot.IdLotu