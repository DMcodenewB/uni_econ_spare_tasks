use ZaliczenieBD_181960
go

drop table Bilet;
drop table Lot;
drop table Lotnisko;
drop table Pasa�er;
drop table Pilot;
drop table Samolot;