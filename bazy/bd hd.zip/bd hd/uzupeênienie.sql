use ZaliczenieBD_181960
go

--dodanie samolot�w

insert into Samolot(Model,MaksPasa�er�w,Pojemno��Baku,MaksPr�dko��,DataPrzyj�cia,CzyRejsowy) values ('Boeing 737',330,48500,733,'2016-07-18',1);
insert into Samolot(Model,MaksPasa�er�w,Pojemno��Baku,MaksPr�dko��,DataPrzyj�cia,CzyRejsowy) values ('Boeing 777',299,44900,750,'2017-07-19',1);
insert into Samolot(Model,MaksPasa�er�w,Pojemno��Baku,MaksPr�dko��,DataPrzyj�cia,CzyRejsowy) values ('Boeing 767',256,43500,847,'1993-10-25',1);
insert into Samolot(Model,MaksPasa�er�w,Pojemno��Baku,MaksPr�dko��,DataPrzyj�cia,CzyRejsowy) values ('Boeing 787',133,19800,739,'2002-07-25',0);
insert into Samolot(Model,MaksPasa�er�w,Pojemno��Baku,MaksPr�dko��,DataPrzyj�cia,CzyRejsowy) values ('Airbus A220',309,47200,763,'2014-09-09',1);
insert into Samolot(Model,MaksPasa�er�w,Pojemno��Baku,MaksPr�dko��,DataPrzyj�cia,CzyRejsowy) values ('Airbus A300',196,28900,735,'2018-07-28',0);
insert into Samolot(Model,MaksPasa�er�w,Pojemno��Baku,MaksPr�dko��,DataPrzyj�cia,CzyRejsowy) values ('Airbus A318',349,44900,642,'1993-01-31',1);

--dodanie lotnisk

insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Montego Bay','Jamaica','MBJ',1);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Durango','Mexico','DGO',0);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Deer Lake, NF','Canada','YDF',0);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Scottsbluff, NE','USA','BFF',0);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Minneapolis, MN','USA','MSP',0);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Medicine Hat, AB','Canada','YXH',0);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Cape Girardeau, MO','USA','CGI',0);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Lugano','Switzerland','LUG',0);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Storuman','Sweden','SQO',0);
insert into Lotnisko(NazwaLotniska,Kraj,SkrotLotniska,CzyObslugujeRejsowe) values ('Stornoway, Isle of Lewis','Scotland','SYY',0);

--dodanie pilot�w

insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Hooper','K',62,3021);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Friedman','M',26,1054);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Shepard','M',27,2513);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Mason','K',57,5314);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Perkins','M',44,940);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Whitney','M',46,1255);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Wilson','K',53,1735);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Sexton','K',29,4145);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Bell','K',25,3122);
insert into Pilot(Nazwisko,P�e�,Wiek,Ilo��GodzinLotu) values ('Bean','K',25,1461);


--dodanie lot�w

insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100000,151,60,'2021-12-08','21:30','02:30',1014,'Uganda','Sydnee','Mclaughlin','+61510316341','Kenya');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100101,141,50,'2020-12-29','01:40','07:00',1018,'Iran','Dangelo','Barton','+89899951132','Morocco');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100202,101,80,'2020-11-20','19:40','06:00',1018,'Iraq','Bradley','Pope','+1267570711','Bangladesh');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100303,161,40,'2020-02-29','17:10','05:40',1006,'India','Isabelle','Sanford','+54235997342','Sudan');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100404,151,20,'2021-07-21','15:40','10:40',1004,'Nigeria','Maci','Blackwell','+59235628562','Germany');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100505,131,90,'2020-08-22','01:10','09:10',1012,'China','Dangelo','Barton','+40127801759','China');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100606,161,100,'2021-07-17','10:50','03:30',1000,'Egypt','Gabriella','Ayers','+19065646779','United Kingdom');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100707,141,10,'2021-01-27','03:00','09:20',1010,'Algeria','Jada','Townsend','+96664218482','Sudan');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100808,131,70,'2021-03-16','06:00','04:00',1004,'Spain','Lisa','Solomon','+82261061628','Uganda');
insert into LotPasa�era(IdBiletu,IdSamolotu,IdPilota,DataWylotu,GodzinaWylotu,CzasLotu,IdLotniskoWylotu,CelLotu,Imi�,Nazwisko,NrTel,KrajPochodzenia) values (100909,101,30,'2021-01-21','10:10','08:30',1012,'Ukraine','Fernanda','Lin','+4484289090','Italy');


